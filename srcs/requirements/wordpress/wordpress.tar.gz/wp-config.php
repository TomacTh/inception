<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', getenv('DB_NAME') );

/** Database username */
define( 'DB_USER', getenv('DB_USER') );

/** Database password */
define( 'DB_PASSWORD', getenv('DB_PASSWORD') );

/** Database hostname */
define( 'DB_HOST', getenv('DB_HOST') );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

define( 'WP_REDIS_HOST', getenv('WP_REDIS_HOST') );

define( 'WP_REDIS_PORT', getenv('WP_REDIS_PORT') );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'ja8ffI^8UKl.g<*qo}eBY+J;`29!8r&5/kU/6tmH EJx(K%gwT^# {uPV^nC/6%+' );
define( 'SECURE_AUTH_KEY',   '2;. VyGTGdyMO5_&N}NT/F-29K;/L,IL6fEp>~^-}az8K>R8[a]Ku|HB1m7k@gHh' );
define( 'LOGGED_IN_KEY',     'z7GeW7_#b@LkZ/?$$AW^{AMA@i^~I3ZhwuW9/t~Lgn`9_|uKcsN<S1jM;K9<l5p)' );
define( 'NONCE_KEY',         'GH`NHcAH7ihZQwp*u[d*f^2d(L-,5JsZ~_uFo+[Q7-wgb,;WNS@`]J@uXbsfd<co' );
define( 'AUTH_SALT',         'zFM?b8}WzC|R{C1p-Gm-PuDPF~4|3n|/V$,WhC:lgkhZSUI~io;_lS^ON{=B@cd7' );
define( 'SECURE_AUTH_SALT',  'Gj?MduCjS.@D5FjwD^z!om<m<v!m,9Phu=|?a8Nf(lVOd_;SR;02}TRt?$pu}Jk?' );
define( 'LOGGED_IN_SALT',    'dTytUI0gm>g[rIv)1GEcc>L9phc]4%C_V],*C9].`H>?]#nvohpc-[COSkeF{#9_' );
define( 'NONCE_SALT',        'VPc}I$(wXo)CJ;a##vi_UH}WHu!hvc7!G!,hZX!k2!zZ(nRfl?%](NE-l?[|@(Hq' );
define( 'WP_CACHE_KEY_SALT', 'qf=`v@;AR[,pgr;rjNTZg3YW(&+}@nOaU6#Ingt04L mSLBv!@;Ovph7jjm~:Wh ' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );


/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
